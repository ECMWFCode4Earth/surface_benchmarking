Welcome to the land verification tool! The tool provides an independent validation of soil moisture and soil temperature
data using in situ observtions from the international soil moisture network. More detailed information is also available 
on the confluence page: 
https://confluence.ecmwf.int/display/~dadf/LANDVER 

Please follow these instructions to validate one or more experiments:


1. Extracting and preparing the soil moisture analysis data:

    1.1 The required user-defined variables are in the file Options_namelist.py.  
        Select the period you wish to extract/validate the SM analysis data (e.g. 1st January 2006 to 31st December 2010):

        analysis_period = ['2006-01-01','2010-12-31] #Analysis period.

        The period should be a minimum of 3 months, no earlier than 1998-01-01 and no later than 2021-12-31. 

    1.2 Select one to five experiments to validate in Options_namelist.py, which will require available data over the analysis period.
        The experiments can have different configurations, but must contain daily global soil moisture and soil temperature outputs.
        Make sure all the fields are filled in for each of the experiments in "EXPVER". The following example validates ERA5, 
        the RD experiment "hlky" and "ERA5-land". Notice that ERA5 and ERA5-land both have the same EXPVER but have a different 
        CLASS for the MARS retrieval. The EXPNAME provides a useful description of the experiments for the validation output. 
        The first experiment is always the "control".
    
        #Experimental parameters
        EXPVER =    ["0001","hlky","0001"] #Experiment names needed for extraction, preprocessing and validation 
        #First experiment is considered the control 
        CLASS =     ["EA","rd","ERA5L"]
        TYPE =      ["AN","AN","AN"]
        ANOFFSET =  ["9","9","9"]
        STREAM =    ["oper","oper","oper"]
        REPRES =    ["SH","SH","SH"]
        LEVTYPE =   ["SFC","SFC","SFC"]
        TIME      = ["00/12","00/12","00/12"] 
        STEP =      ["00","00","00"]
        DOMAIN =    ["G","G","G"]
        GRID =      ["av","av","av"]
        EXPNAME =  ["ERA5 control", "SEKF analysis CY47R2", "ERA5-land"]

    1.3 Check the default parameters in the file Common functions.py, Class LDAS_config. Change the parameters, if preferred. 

    - By default, both soil moisture and soil temperature analysis data are extracted, preprocessed and validated. But they can also be validated separately, e.g.

    self.extract_SM = True  # Extract soil moisture grib files from MARS (required for preprocessing)
    self.extract_ST = False 
    self.pre_process_SM = (
        True  # Preprocess soil moisture (required for validation)
    )
    self.pre_process_ST = (
        False  
    )
    self.validate_SM = True  # Validate soil moisture
    self.validate_ST = False  

    - To avoid preprocessing the analysis data twice, set self.pre_process_SM/self.pre_process_ST to False.

    1.4 Select the in situ networks where you want to preprocess the analysis data (nearest neighbour) e.g.
    Network = ['USCRN', 'SNOTEL', 'SCAN', 'SMOSMANIA']  # Can be any combination of 'USCRN', 'SNOTEL', 'SCAN', 'SMOSMANIA', 'REMEDHUS', 'OZNET'

    Please see the confluence page for information on the other parameters.

2.  Run the preprocessing/validation: 
    - If not already loaded, load the python3 module:
    module load python3

    - Perform the preprocessing/validation:
    ./landver Options_namelist.py

3.  At the end of the validation an html output is generated, which includes plots and tables of the scores (Pearson R, RMSD, unbiased RMSD, bias)
    See the confluence page for an example.












